﻿namespace HotelReservation
{
    partial class frmGcashFinalSummary
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGcashFinalSummary));
            this.label22 = new System.Windows.Forms.Label();
            this.lblAddress = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblContact = new System.Windows.Forms.Label();
            this.lblFullname = new System.Windows.Forms.Label();
            this.lblRefid = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.lblTotalamount = new System.Windows.Forms.Label();
            this.lblDatein = new System.Windows.Forms.Label();
            this.lblDateout = new System.Windows.Forms.Label();
            this.lblNoofnights = new System.Windows.Forms.Label();
            this.lblTypeofroom = new System.Windows.Forms.Label();
            this.lblNoofadults = new System.Windows.Forms.Label();
            this.lblNoofChildren = new System.Windows.Forms.Label();
            this.lblRoomrate = new System.Windows.Forms.Label();
            this.labelAccname = new System.Windows.Forms.Label();
            this.labelCellno = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.lblDiscount = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(27, 14);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(157, 25);
            this.label22.TabIndex = 40;
            this.label22.Text = "Official Receipt";
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(167, 207);
            this.lblAddress.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(211, 13);
            this.lblAddress.TabIndex = 154;
            this.lblAddress.Text = "                                                                    ";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(167, 178);
            this.lblEmail.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(211, 13);
            this.lblEmail.TabIndex = 153;
            this.lblEmail.Text = "                                                                    ";
            // 
            // lblContact
            // 
            this.lblContact.AutoSize = true;
            this.lblContact.Location = new System.Drawing.Point(167, 149);
            this.lblContact.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblContact.Name = "lblContact";
            this.lblContact.Size = new System.Drawing.Size(211, 13);
            this.lblContact.TabIndex = 152;
            this.lblContact.Text = "                                                                    ";
            // 
            // lblFullname
            // 
            this.lblFullname.AutoSize = true;
            this.lblFullname.Location = new System.Drawing.Point(164, 117);
            this.lblFullname.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblFullname.Name = "lblFullname";
            this.lblFullname.Size = new System.Drawing.Size(211, 13);
            this.lblFullname.TabIndex = 151;
            this.lblFullname.Text = "                                                                    ";
            // 
            // lblRefid
            // 
            this.lblRefid.AutoSize = true;
            this.lblRefid.Location = new System.Drawing.Point(164, 89);
            this.lblRefid.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRefid.Name = "lblRefid";
            this.lblRefid.Size = new System.Drawing.Size(211, 13);
            this.lblRefid.TabIndex = 150;
            this.lblRefid.Text = "                                                                    ";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(29, 227);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(145, 20);
            this.label17.TabIndex = 149;
            this.label17.Text = "Rate Information";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(29, 53);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(155, 20);
            this.label16.TabIndex = 148;
            this.label16.Text = "Guest Information";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(30, 462);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(80, 16);
            this.label14.TabIndex = 147;
            this.label14.Text = "Room Rate:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(31, 435);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(98, 16);
            this.label13.TabIndex = 146;
            this.label13.Text = "No. of Children:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(31, 408);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(86, 16);
            this.label12.TabIndex = 145;
            this.label12.Text = "No. of Adults:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(29, 377);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(97, 16);
            this.label11.TabIndex = 144;
            this.label11.Text = "Type of Room:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(29, 346);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(63, 16);
            this.label10.TabIndex = 143;
            this.label10.Text = "Discount:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(30, 317);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(84, 16);
            this.label9.TabIndex = 142;
            this.label9.Text = "No. of Nights";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(30, 287);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(63, 16);
            this.label8.TabIndex = 141;
            this.label8.Text = "Date Out:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(30, 259);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 16);
            this.label7.TabIndex = 140;
            this.label7.Text = "Date In:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(29, 204);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 16);
            this.label6.TabIndex = 139;
            this.label6.Text = "Address:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(29, 175);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 16);
            this.label5.TabIndex = 138;
            this.label5.Text = "Email:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(29, 146);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 16);
            this.label4.TabIndex = 137;
            this.label4.Text = "Contact No.:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(29, 114);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 16);
            this.label3.TabIndex = 136;
            this.label3.Text = "Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(30, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 16);
            this.label2.TabIndex = 135;
            this.label2.Text = "Reference ID:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(31, 567);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(109, 16);
            this.label20.TabIndex = 166;
            this.label20.Text = "Accommodation:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(31, 538);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(120, 16);
            this.label19.TabIndex = 165;
            this.label19.Text = "Cleaning Supplies:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(31, 513);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(54, 16);
            this.label18.TabIndex = 164;
            this.label18.Text = "Utilities:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(30, 488);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(131, 20);
            this.label15.TabIndex = 163;
            this.label15.Text = "Other Charges:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(33, 598);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(142, 24);
            this.label21.TabIndex = 170;
            this.label21.Text = "Gcash Payment";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(36, 625);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(99, 16);
            this.label23.TabIndex = 171;
            this.label23.Text = "Account Name:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(34, 645);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(103, 16);
            this.label24.TabIndex = 172;
            this.label24.Text = "GCash Number:";
            // 
            // lblTotalamount
            // 
            this.lblTotalamount.AutoSize = true;
            this.lblTotalamount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalamount.Location = new System.Drawing.Point(157, 679);
            this.lblTotalamount.Name = "lblTotalamount";
            this.lblTotalamount.Size = new System.Drawing.Size(0, 20);
            this.lblTotalamount.TabIndex = 174;
            // 
            // lblDatein
            // 
            this.lblDatein.AutoSize = true;
            this.lblDatein.Location = new System.Drawing.Point(167, 262);
            this.lblDatein.Name = "lblDatein";
            this.lblDatein.Size = new System.Drawing.Size(154, 13);
            this.lblDatein.TabIndex = 180;
            this.lblDatein.Text = "                                                 ";
            // 
            // lblDateout
            // 
            this.lblDateout.AutoSize = true;
            this.lblDateout.Location = new System.Drawing.Point(167, 290);
            this.lblDateout.Name = "lblDateout";
            this.lblDateout.Size = new System.Drawing.Size(154, 13);
            this.lblDateout.TabIndex = 181;
            this.lblDateout.Text = "                                                 ";
            // 
            // lblNoofnights
            // 
            this.lblNoofnights.AutoSize = true;
            this.lblNoofnights.Location = new System.Drawing.Point(167, 320);
            this.lblNoofnights.Name = "lblNoofnights";
            this.lblNoofnights.Size = new System.Drawing.Size(154, 13);
            this.lblNoofnights.TabIndex = 182;
            this.lblNoofnights.Text = "                                                 ";
            // 
            // lblTypeofroom
            // 
            this.lblTypeofroom.AutoSize = true;
            this.lblTypeofroom.Location = new System.Drawing.Point(167, 377);
            this.lblTypeofroom.Name = "lblTypeofroom";
            this.lblTypeofroom.Size = new System.Drawing.Size(154, 13);
            this.lblTypeofroom.TabIndex = 183;
            this.lblTypeofroom.Text = "                                                 ";
            // 
            // lblNoofadults
            // 
            this.lblNoofadults.AutoSize = true;
            this.lblNoofadults.Location = new System.Drawing.Point(167, 408);
            this.lblNoofadults.Name = "lblNoofadults";
            this.lblNoofadults.Size = new System.Drawing.Size(154, 13);
            this.lblNoofadults.TabIndex = 184;
            this.lblNoofadults.Text = "                                                 ";
            // 
            // lblNoofChildren
            // 
            this.lblNoofChildren.AutoSize = true;
            this.lblNoofChildren.Location = new System.Drawing.Point(167, 438);
            this.lblNoofChildren.Name = "lblNoofChildren";
            this.lblNoofChildren.Size = new System.Drawing.Size(154, 13);
            this.lblNoofChildren.TabIndex = 185;
            this.lblNoofChildren.Text = "                                                 ";
            // 
            // lblRoomrate
            // 
            this.lblRoomrate.AutoSize = true;
            this.lblRoomrate.Location = new System.Drawing.Point(167, 465);
            this.lblRoomrate.Name = "lblRoomrate";
            this.lblRoomrate.Size = new System.Drawing.Size(154, 13);
            this.lblRoomrate.TabIndex = 186;
            this.lblRoomrate.Text = "                                                 ";
            // 
            // labelAccname
            // 
            this.labelAccname.AutoSize = true;
            this.labelAccname.Location = new System.Drawing.Point(163, 619);
            this.labelAccname.Name = "labelAccname";
            this.labelAccname.Size = new System.Drawing.Size(154, 13);
            this.labelAccname.TabIndex = 190;
            this.labelAccname.Text = "                                                 ";
            // 
            // labelCellno
            // 
            this.labelCellno.AutoSize = true;
            this.labelCellno.Location = new System.Drawing.Point(163, 639);
            this.labelCellno.Name = "labelCellno";
            this.labelCellno.Size = new System.Drawing.Size(154, 13);
            this.labelCellno.TabIndex = 191;
            this.labelCellno.Text = "                                                 ";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(35, 679);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(116, 20);
            this.label28.TabIndex = 196;
            this.label28.Text = "Amount Paid:";
            // 
            // lblDiscount
            // 
            this.lblDiscount.AutoSize = true;
            this.lblDiscount.Location = new System.Drawing.Point(167, 348);
            this.lblDiscount.Name = "lblDiscount";
            this.lblDiscount.Size = new System.Drawing.Size(154, 13);
            this.lblDiscount.TabIndex = 200;
            this.lblDiscount.Text = "                                                 ";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(161, 714);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 201;
            this.button1.Text = "Done";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label25.Location = new System.Drawing.Point(167, 541);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(184, 13);
            this.label25.TabIndex = 204;
            this.label25.Text = "308.00                                                ";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label26.Location = new System.Drawing.Point(166, 569);
            this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(184, 13);
            this.label26.TabIndex = 203;
            this.label26.Text = "508.00                                                ";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label29.Location = new System.Drawing.Point(167, 516);
            this.label29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(193, 13);
            this.label29.TabIndex = 202;
            this.label29.Text = "203.00                                                   ";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(185, 10);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(36, 35);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 259;
            this.pictureBox3.TabStop = false;
            // 
            // frmGcashFinalSummary
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(402, 749);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblDiscount);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.labelCellno);
            this.Controls.Add(this.labelAccname);
            this.Controls.Add(this.lblRoomrate);
            this.Controls.Add(this.lblNoofChildren);
            this.Controls.Add(this.lblNoofadults);
            this.Controls.Add(this.lblTypeofroom);
            this.Controls.Add(this.lblNoofnights);
            this.Controls.Add(this.lblDateout);
            this.Controls.Add(this.lblDatein);
            this.Controls.Add(this.lblTotalamount);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.lblAddress);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.lblContact);
            this.Controls.Add(this.lblFullname);
            this.Controls.Add(this.lblRefid);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label22);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmGcashFinalSummary";
            this.Text = "GCash Receipt";
            this.Load += new System.EventHandler(this.frmGcashFinalSummary_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblContact;
        private System.Windows.Forms.Label lblFullname;
        private System.Windows.Forms.Label lblRefid;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label lblTotalamount;
        private System.Windows.Forms.Label lblDatein;
        private System.Windows.Forms.Label lblDateout;
        private System.Windows.Forms.Label lblNoofnights;
        private System.Windows.Forms.Label lblTypeofroom;
        private System.Windows.Forms.Label lblNoofadults;
        private System.Windows.Forms.Label lblNoofChildren;
        private System.Windows.Forms.Label lblRoomrate;
        private System.Windows.Forms.Label labelAccname;
        private System.Windows.Forms.Label labelCellno;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label lblDiscount;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.PictureBox pictureBox3;
    }
}